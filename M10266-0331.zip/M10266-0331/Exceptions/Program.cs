﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exceptions
{
    class Program
    {

        static void Test(string s1, string s2)
        {
            try
            {
                int n1 = int.Parse(s1);
                int n2 = int.Parse(s2);

                if (n1 < 0 || n1 > 100)
                    throw new ArgumentException("n1 out of (0, 100)");


                int n = n1 / n2;
                Console.WriteLine(n);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.ToString());
            }
            /*
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }*/
            finally
            {
                Console.WriteLine("finally");
            }

            Console.WriteLine("продолжение test");

        }
        
        static void Main(string[] args)
        {
            try
            {
                checked
                {
                    int a = int.MaxValue;
                    Console.WriteLine(a);
                    //a++;
                    a = unchecked(a + 1);


                    Console.WriteLine(a);
                }
                
                Test("123", "0");
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine(ex.Message);
                //throw ex;
                throw new Exception("Проблема", ex);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.ToString());
            }
            Console.WriteLine("продолжение main");
        }
    }
}
