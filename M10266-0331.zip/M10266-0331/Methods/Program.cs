﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Methods
{
    public class Program
    {
        public static int GCD(int a, int b)
        {
            if (a < b)
            {
                int c = a;
                a = b;
                b = c;
            }
            // a >= b
            int k;
            while ((k = a % b) != 0)
            {
                a = b; b = k;
            }

            return b;
        
        }
        public static double Average(params int[] a)
        {
            int summa = 0;
            foreach (int k in a)
                summa += k;

            return (double)summa / a.Length;
        
        }
        
        public static double Average(int a, int b)
        {
            double avg = (a + b) / 2D;
            return avg;
        }
        /*
        public static void SayHello()
        {
            Console.WriteLine("Привет!");
        }
        public static void SayHello(string userName)
        {
            //Console.WriteLine("Привет, {0}!", userName);
            SayHello(userName, 18);
        }*/
        
        public static void SayHello(string userName = "Незнакомец",
            int age = 18)
        {
            Console.WriteLine("Привет, {0} - {1}!", userName, age);
            //return;
        }

        static void test1(int a)
        {
            a++;
            Console.WriteLine("test1 a = {0}", a);
        }
        static void test2(int[] a)
        {
            a[0]++;
            Console.WriteLine("test2 a = {0}", a[0]);
        }
        static void test3(ref int a)
        {
            a++;
            Console.WriteLine("test3 a = {0}", a);
        }
        static void test4(out int a)
        {
            a = 10;
            Console.WriteLine("test4 a = {0}", a);
        }

        
        static void Main(string[] args)
        {
            string s = "123";
            int z;
            if (int.TryParse(s, out z))
            {
                Console.WriteLine(z);
            }
            
            {
                int a = 10;
                test1(a+1);
                Console.WriteLine("main1 a = {0}", a);
            }
            {
                int[] a = {10};
                test2(a);
                Console.WriteLine("main2 a = {0}", a[0]);
            }
            {
                int a = 10;
                a = a + 1;
                test3(ref a);
                Console.WriteLine("main3 a = {0}", a);
            }
            {
                int a;
                test4(out a);
                Console.WriteLine("main4 a = {0}", a);
            }

            {




                //Program p = new Program();
                //p.SayHello();
                //Program.SayHello();
                SayHello("Сергей", 36);
                SayHello("Костя");
                SayHello("Саша", 4);
                SayHello(age: 32, userName: "Unknown");
                SayHello();

                double x = Average(10, 11);
                Console.WriteLine(x);

                Console.WriteLine(Average(10, 12));
                

                int a1;
                int b1 = a1 = 11;
                
                int[] q;
                double a = Average(q = new int[] { 10, 11, 12, 13 });

                a = Average(10, 11, 12, 13);
                Console.WriteLine(a);

                Console.WriteLine(GCD(21, 35));
            }

        }
    }
}
