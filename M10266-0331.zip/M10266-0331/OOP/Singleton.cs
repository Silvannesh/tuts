﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP
{
    public class Singleton
    {

        private Singleton()
        { 
        }

        private static Singleton instance = null;
        private static object myLock = new object();

        public static Singleton getInstance()
        {
            if (instance == null)
            {
                lock (myLock)
                {
                    if (instance == null)
                        instance = new Singleton();
                }
            }

            return instance;

            
        }
    }
}
