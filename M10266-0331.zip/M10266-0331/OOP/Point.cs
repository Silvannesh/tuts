﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP
{
    public class Point : GraphObject
    {
        public int X
        { get; set; }
        public int Y
        { get; set; }

        public int this[string index]
        {
            get
            {
                switch (index.ToUpper())
                {
                    case "X": return X;
                    case "Y": return Y;
                    default: throw new IndexOutOfRangeException();
                }
            }
            set
            {
                switch (index.ToUpper())
                {
                    case "X": X = value; break;
                    case "Y": Y = value; break;
                    default: throw new IndexOutOfRangeException();
                }
            }
        }
        public int this[int index]
        {
            get
            {
                switch (index)
                {
                    case 0: return X;
                    case 1: return Y;
                    default: throw new IndexOutOfRangeException();
                }
            }
            set 
            {
                switch (index)
                {
                    case 0: X = value; break;
                    case 1: Y = value; break;
                    default: throw new IndexOutOfRangeException();
                }
            }
        }



        //public new string Color;

        /*
        public Point(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
            this.Color = DEFAULT_COLOR;
        }*/

        public Point(int X, int Y, string color = DEFAULT_COLOR)
            : base(color)
        {
            this.X = X;
            this.Y = Y;
            //this.Color = color;
        }

        public void MoveBy(int dx, int dy)
        {
            X += dx;
            Y += dy;
        }

        public sealed override void Draw()
        {
            //base.Draw();
            Console.WriteLine("Point ({0}, {1}) color: {2}",
                X, Y, Color);
        }

        public override string ToString()
        {
            return string.Format("Point ({0}, {1}) color: {2}",
                X, Y, Color);
        }
    }
}
