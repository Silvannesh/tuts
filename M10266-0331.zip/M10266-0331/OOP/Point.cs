﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP
{
    public class Point : GraphObject, IComparable<Point>
    {
        public int X
        { get; set; }
        public int Y
        { get; set; }

        public int this[string index]
        {
            get
            {
                switch (index.ToUpper())
                {
                    case "X": return X;
                    case "Y": return Y;
                    default: throw new IndexOutOfRangeException();
                }
            }
            set
            {
                switch (index.ToUpper())
                {
                    case "X": X = value; break;
                    case "Y": Y = value; break;
                    default: throw new IndexOutOfRangeException();
                }
            }
        }
        public int this[int index]
        {
            get
            {
                switch (index)
                {
                    case 0: return X;
                    case 1: return Y;
                    default: throw new IndexOutOfRangeException();
                }
            }
            set 
            {
                switch (index)
                {
                    case 0: X = value; break;
                    case 1: Y = value; break;
                    default: throw new IndexOutOfRangeException();
                }
            }
        }



        //public new string Color;

        /*
        public Point(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
            this.Color = DEFAULT_COLOR;
        }*/

        public Point(int X, int Y, string color = DEFAULT_COLOR)
            : base(color)
        {
            this.X = X;
            this.Y = Y;
            //this.Color = color;
        }

        public void MoveBy(int dx, int dy)
        {
            X += dx;
            Y += dy;
        }

        public sealed override void Draw()
        {
            //base.Draw();
            Console.WriteLine("Point ({0}, {1}) color: {2}",
                X, Y, Color);
        }

        public override string ToString()
        {
            return string.Format("Point ({0}, {1}) color: {2}",
                X, Y, Color);
        }

        public double RVLength
        {
            get
            {
                return Math.Sqrt(X * X + Y * Y);
            }
        }



        public static Point operator +(Point p1, Point p2)
        {
            return new Point(p1.X + p2.X, p1.Y + p2.Y);
        }

        public override bool Equals(object obj)
        {
            Point p = obj as Point;
            if (object.ReferenceEquals(p, null)) return false;
            return this.X == p.X && this.Y == p.Y;
        }

        public static bool operator ==(Point p1, Point p2)
        {
            return object.Equals(p1, p2);
        }
        public static bool operator !=(Point p1, Point p2)
        {
            return !(p1 == p2);
        }

        public int CompareTo(Point p)
        {
            if (this == p) return 0;
            return (this.RVLength > p.RVLength) ? 1 : -1;
            
        }

        public static bool operator >(Point p1, Point p2)
        {
            return p1.CompareTo(p2) > 0;
        }
        public static bool operator <(Point p1, Point p2)
        {
            return p1.CompareTo(p2) < 0;
        }

        public static explicit operator double(Point p)
        {
            return p.RVLength;
        }
    }
}
