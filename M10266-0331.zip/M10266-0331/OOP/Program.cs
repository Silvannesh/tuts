﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP
{
    struct Complex
    {
        public double Real;
        public double Imagine;

        public Complex(double real, double imagine = 0D)
        {
            this.Real = real;
            this.Imagine = imagine;
        }

        public static Complex operator +(Complex c1, Complex c2)
        {
            return new Complex(c1.Real + c2.Real, c1.Imagine + c2.Imagine);
        }
        public static bool operator ==(Complex c1, Complex c2)
        {
            return c1.Real == c2.Real && c1.Imagine == c2.Imagine;
        }
        public static bool operator !=(Complex c1, Complex c2)
        {
            return !(c1 == c2);
        }

        public void Show()
        {
            Console.WriteLine("({0}, {1})", Real, Imagine);
        }

        public Complex Add(Complex c)
        {
            return new Complex(this.Real + c.Real, this.Imagine + c.Imagine);
        }
    }
    
    public partial class Person
    {
        public string EMail
        { get; set; }

        partial void Verify()
        {
            Console.WriteLine("проверка");
        }
    }

    struct Money
    {
        public decimal Summa;
        public string Currency;
        public Money(decimal summa)
        {
            this.Summa = 0M;
            this.Currency = "RUB";
        }

        public Money(decimal summa, string currency)
        {
            this.Summa = summa;
            this.Currency = currency;
        }

        public void Show()
        {
            Console.WriteLine("{0}{1}", Summa, Currency);
        }
    }

    public static class MyContainer
    {
        public static int k
        { get; set; }
        public static void Test()
        { }

        public static void Scale(this Circle s, double factor)
        {
            Console.WriteLine("Extension scale");
            s.Radius = (int)(s.Radius * factor);
        }

        public static void MoveX(this IScaleable s, int dx)
        {
            if (s is Circle)
            {
                Circle c = (Circle)s;
                c.X += dx;
            }
        }

        public static string Capitalize(this string s)
        {
            string[] words = s.Split(' ');
            StringBuilder sb = new StringBuilder();
            foreach(string word in words)
            {
                if (word.Length >= 1)
                {
                    sb.Append(char.ToUpper(word[0]));
                    sb.Append(word.Substring(1).ToLower());
                    sb.Append(' ');
                }
            }
            return sb.ToString();
        }
    }


    class Program
    {
        static void Test()
        {
            Console.WriteLine("Test");
        }
        static void Main(string[] args)
        {
            {
                Point p1 = new Point(10, 10);
                Point p2 = new Point(10, 1);

                if (p1 > p2)
                    Console.WriteLine("p1 > p2");
                else
                    Console.WriteLine("p1 != p2");

                Point p3 = p1 + p2;
                Console.WriteLine(p3);

                double r = (double)p1; // p1.RVLength

                Circle c1 = new Circle(0, 0, 10);
                Circle c2 = c1 * 2.5; //2.5 * c1;
                c2.Draw();
    
            }

            {
                Person p1 = new Person("Sergey", 36) { EMail = "sergey@shuykov.ru" };

                var a1 = new
                {
                    Product = "Книга",
                    Price = 200M,
                    Quantity = 10,
                    Test = new Action(Program.Test)
                };
                Console.WriteLine(a1.Product);
                a1.Test();
                Console.WriteLine(a1.GetType().FullName);


                //p1.EMail = "sergey@shuykov.ru";


            }
            {
                string s = "hello sergey";
                string s1 = //MyContainer.Capitalize(s)
                    s.Capitalize();

                Console.WriteLine(s1); // Hello Sergey
            }
            {
                Circle.Inner inner;
                MyContainer.Test();
                MyContainer.k = 100;
            }

            {
                /*
                int k = 7;
                if (k is IComparable)
                    Console.WriteLine("yes");*/
                //BankAccount ba1 = new BankAccount("Sergey");
                int ba1 = 7;
                Console.WriteLine(ba1.GetType().IsValueType);


            }
            {
                string s = "123";
                char c = s[0];
            }
            {
                BankAccount ba1 = new BankAccount("Sergey");
                BankAccount ba2 = new BankAccount("Kosty");
                ba1.Deposit(200000);
                BankAccount.Transfer(ba1, ba2, 5000);

                Console.WriteLine(ba1);
                Console.WriteLine(ba2);
            }

            {
                Singleton s1 = Singleton.getInstance();
                Singleton s2 = Singleton.getInstance();
            }

            {
                //GraphObject gn = new GraphObject();


                Point p1 = new Point(10, 20);
                p1[0] = 99;
                p1[1] = 199;
                p1["x"] = 99;
                p1["y"] = 199;
                Console.WriteLine(p1[0]);


                p1.MoveBy(1, 2);
                //p1.Color = "red";
                //p1.Draw();

                object o1 = p1;

                //Console.WriteLine(p1);

                GraphObject g1 = new Point(300, 300);
                g1.Draw();
                //g1 = new Circle(1, 1, 1);

                if (g1 is Point)
                {
                    Point p3 = (Point)g1;
                    p3.MoveBy(1, 1);
                }

                Point p4 = g1 as Point;
                if (p4 != null)
                    p4.MoveBy(1, 1);


                g1.Draw();

                Circle c1 = new Circle(100, 200, 30, "Green");
                c1.MoveX(10);
                c1.Scale(2.5);

                IScaleable s1 = c1;
                c1.Scale(2); // /
                s1.Scale(2); // *
                //c1.Radius = 100;

                //Console.WriteLine(c1.getRadius());
                //c1.Radius = 100; //c1.setRadius(100);

                Console.WriteLine(c1.Radius); //c1.getRadius()


                g1 = c1;

                g1.Draw();

                //System.Object
                object o2 = c1;
                //o2.Draw();

                dynamic d1 = new Circle(10, 20, 30);
                d1.Radius = 20;
                d1 = new Point(10, 10);
                d1.MoveBy(1, 1);
                dynamic d3 = 10;



                object o3 = "String";
                //GraphObject g2 = c1;
                long k = 10;
                object ok = k; // boxing
                //int q = k; // var q = k
                long k2 = (long)ok;


                //g2.Draw();


                GraphObject.ColorScene("orange");

                GraphObject.DrawScene();

                //p1.Draw();
            }


            {
                Complex c1 = new Complex(1, 0);
                Complex c2 = new Complex(0, 1);
                //Complex c3 = c1.Add(c2);
                Complex c3 = c1 + c2;

                c3.Show();



                Money m1 = new Money(100, "RUB");
                //m1.Summa = 100;
                //m1.Currency = "RUB";
                Money m2 = m1;
                m2.Currency = "USD";
                m1.Show();

                Money? m3 = new Money(200, "YEN");
                if (m3.HasValue)
                {
                    m3.Value.Show();
                }

                m3 = null;

                m3 = m1;


                int a = 10;
                int? b = null;
                Console.WriteLine(b ?? -1000);
                /*
                unsafe
                {
                    int* q;
                }*/



                //if (b != null)
                if (b.HasValue)
                {
                    int c = b.Value;
                }

                string pq = "sergey"; // new Person();
                //Console.WriteLine( (pq != null) ? pq : "null"    );
                Console.WriteLine(pq ?? "null");

                Console.WriteLine("Start");
                //Console.WriteLine(Person.counter);
                Console.WriteLine(typeof(Person).FullName);
                Console.WriteLine("After Person");

                //Console.WriteLine(Person.counter);
                Person.ShowTotal();

                Person p = new Person("Сергей", 36);
                Person p4 = p;
                p4.Age = 37;
                //p.Name = "Сергей";
                //p.Age = 36;

                Person p2 = new Person("Наталия", 32);
                //p2.Name = "Наталия";
                //p2.Age = 32;

                Person p3 = new Person();

                p.Show();
                p2.Show();
                p3.Show();

                //Console.WriteLine(Person.counter);
                Person.ShowTotal();
                //int q = 6;
                var q = 6;
                var z = "adkfjas";

                string[] nm = { "Sergey", "Kosty" };

                foreach (var w in nm)
                    Console.WriteLine(w);
            }
        }
    }
}
