﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP
{
    public partial class Person
    {
        /*private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }*/
        public string Name
        { get; set; }

        private int birthYear;
        public int Age
        { 
            get
            {
                return DateTime.Now.Year - birthYear;
            }
            set
            {
                birthYear = DateTime.Now.Year - value;
            }

       }

        private static int counter;

        static Person()
        {
            counter = 0;
            Console.WriteLine("static Person()");
        }

        public static void ShowTotal()
        {
            Console.WriteLine("Total persons created: {0}", counter);
        }

        
        public Person()
            : this("Незнакомец")
        { }
        
        public Person(string name)
            : this(name, 19)
        {
            
        }

        public Person(string Name, int Age)
        {
            this.Name = Name;
            this.Age = Age;
            counter++;
        }



        partial void Verify();
        
        public void Show()
        {
            Verify();
            Console.WriteLine("{0} {1}", this.Name, this.Age);
        }
    }
}
