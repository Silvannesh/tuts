﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP
{
    public interface IScaleable
    {
        void Scale(double factor);
    }
    public interface ITest
    {
        int Name { get; }
    }
}
