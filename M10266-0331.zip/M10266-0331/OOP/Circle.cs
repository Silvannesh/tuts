﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP
{
    public class Circle : GraphObject, IScaleable, IColorfull
    {
        enum CircleMode { Normal, Special}

        interface Test
        { }
        
        public abstract class Inner
        {
            public void test(Circle c)
            {
                c.radius *= 2;
            }
        }
        
        public int X, Y;

        private int radius;
        public int Radius
        {
            get
            {
                Inner i;
                return radius;
            }
            set 
            {
                if (value <= 0)
                    throw new ArgumentException("radius <= 0");
                radius = value;
            }
        }

        /*
        public int getRadius()
        {
            return Radius;
        }

        public void setRadius(int r)
        {
            if (r <= 0)
                throw new ArgumentException("radius <= 0");
            Radius = r;
        }*/


        public Circle(int x, int y, int radius, string color = DEFAULT_COLOR)
            : base (color)
        {
            this.X = x;
            this.Y = y;
            this.Radius = radius;
        }

        
        void IScaleable.Scale(double factor)
        {
            Radius = (int)(Radius * factor);
        }
        /*
        public void Scale(double factor)
        {
            Console.WriteLine("Circle scale");
            Radius = (int)(Radius / factor);
        }*/

        public override void Draw()
        {
            Console.WriteLine("Circle ({0}, {1}) R: {2} Color: {3}",
                X, Y, Radius, Color);
        }


        string IColorfull.Color
        {
            get
            {
                return base.Color;
            }
            set
            {
                base.Color = value;
            }
        }
    }
}
