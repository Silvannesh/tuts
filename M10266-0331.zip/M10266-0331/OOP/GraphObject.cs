﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP
{
    /*
        access level        modifier        visibility
        public              public          world
        internal            internal(*)     assembly
    */
    public abstract class GraphObject
    {
        protected class Line
        { 
        
        }
        
        public const string DEFAULT_COLOR = "black";

        /*
            access level        modifier        visibility
            public              public          world
            private             private (*)     this class only
            protected           protected       this class+inheritance
            internal            internal        assembly
            protected internal  protected internal this assembly+inheritance
        */
        protected internal string Color;

        public static List<GraphObject> scene =
            new List<GraphObject>();

        public GraphObject(string color = DEFAULT_COLOR)
        {
            this.Color = color;
            scene.Add(this);
        }

        public static void DrawScene()
        {
            foreach (GraphObject g in scene)
                g.Draw();
        }
        public static void ColorScene(string color)
        {

            foreach (GraphObject g in scene)
            {
                if (g is IColorfull)
                {
                    IColorfull c = (IColorfull)g;
                    c.Color = color;
                }

            }
        }

        public static void ScaleScene(double factor)
        {
            
            foreach (GraphObject g in scene)
            {
                if (g is IScaleable)
                {
                    IScaleable c = (IScaleable)g;
                    c.Scale(factor);
                }
                // VERY BAD
                /*
                if (g is Circle)
                {
                    Circle c = (Circle)g;
                    c.Scale(factor);
                }*/
            }
        }


        public abstract void Draw();
        //{
            //Console.WriteLine("GraphObject Color: {0}", Color);
        //}
    }
}
