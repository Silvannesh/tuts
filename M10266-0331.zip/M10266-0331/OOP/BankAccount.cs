﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOP
{
    public class BankAccount
    {
        private string owner;
        private decimal balance;

        public string Owner
        { get { return owner; } }


        public virtual decimal Balance
        { get { return balance; } }

        public BankAccount(string owner)
        {
            this.owner = owner;
            balance = 0M;
        }

        public void Deposit(decimal summa)
        {
            if (summa < 0) throw new ArgumentException("summa < 0");

            balance += summa;
        }

        public bool Withdraw(decimal summa)
        {
            if (summa < 0) throw new ArgumentException("summa < 0");

            if (balance < summa) return false;
            balance -= summa;
            return true;
        }

        public override string ToString()
        {
            return string.Format("{0, -30} : {1}", Owner, Balance);
        }

        public static bool Transfer(
            BankAccount source, BankAccount dest, decimal summa)
        {
            if (source.Withdraw(summa))
            {
                dest.Deposit(summa);
                return true;
            }
            else
                return false;
        }

    }
}
