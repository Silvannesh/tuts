﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Operators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = -10;

            if (a > 0)
            {
                Console.WriteLine("a больше 0");
                Console.WriteLine("a > 0");
            }
            else
            {
                if (a > -100)
                    Console.WriteLine("a > -100");
                else
                    Console.WriteLine("a не больше 0");
            }

            int x = 0;
            /*
            string s;
            if (x == 0)
                s = "ноль";
            else
                s = "не ноль";*/

            string s = (x == 0) ? "ноль" : "не ноль";

            int n = 20;
            switch (n)
            { 
                case 0:
                case 1:
                    if (true)
                        Console.WriteLine("один");
                    break;
                    //return;
                case 2:
                    Console.WriteLine("два");
                    break;
                case 3:
                    Console.WriteLine("три");
                    break;
                default:
                    Console.WriteLine("много");
                    break;

            }

            int k = 0;
            if (k == 0)
                Console.WriteLine("QQ");

            for (int i = 1; i <= 10; i++) 
            {
                if (i == 3) continue;
                Console.WriteLine(i);
                if (i == 8) break;
            }

            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    Console.Write("{0, 4}", i * j);
                    //if (j == 5) break;
                    //if (j == 5) return;
                    if (j == 5)
                        goto metka;
                }
                Console.WriteLine();
            }

            metka:

            Console.WriteLine("main");

            int y = 2;
            while (y < 1000)
            {
                Console.WriteLine(y);
                y *= 2;
            }

            y = 2000;
            do
            {
                Console.WriteLine(y);
                y *= 2;
            }
            while (y < 1000);

        }
    }
}
