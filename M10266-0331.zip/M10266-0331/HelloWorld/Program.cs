﻿using System;
using C = global::System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Threading;
using System.Globalization;

namespace HelloWorld
{
    class ProgramR
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Привет, мир!");
        }
    }
    
    /// <summary>
    /// My Super class
    /// </summary>
    class Program
    {
        /// <summary>
        /// Entry point
        /// </summary>
        /// <param name="args">Command line parameters</param>
        static void Main(string[] args)
        {
            /*
            global::HelloWorld.Program p;
            ProgramR p1;
            System.String s1;
            String s2;
            C.List<string> c;
             */

            //MessageBox.Show("Привет");
            
            Console.WriteLine("Hello ugly world!"); //dfjghdfj

            string name = "Sergey";
            int age = 36;

            
            // TODO: Доделать в этом месте
            string r = string.Format("Привет, {0} - {1}!", name, age);
            Console.WriteLine("Привет, {0, -10} - {1}!", name, age);
            double d = 2.5;
            Console.WriteLine("d = {0:f7}", d);
            //CultureInfo cInfo = CultureInfo.GetCultureInfo("en-US");
            //Thread.CurrentThread.CurrentCulture = cInfo;
            
            DateTime now = DateTime.Now;
            Console.WriteLine("Время: {0:t}", now);

            string s3 = Console.ReadLine();

            Console.WriteLine("Вы ввели: {0}", s3);
        }
    }
}
