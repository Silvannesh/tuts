﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Methods;

namespace MethodsTest
{
    [TestClass]
    public class ProgramTest
    {
        [TestMethod]
        public void GCDTest()
        {
            int r = Program.GCD(21, 35);
            Assert.AreEqual<int>(7, r);
            int r2 = Program.GCD(35, 21);
            Assert.AreEqual<int>(7, r2);
        }
        [TestMethod]
        public void AverageTest()
        {
            double r = Program.Average(10, 11);
            Assert.AreEqual<double>(10.5, r);
        }
        [TestMethod]
        public void AverageTestN()
        {
            double r = Program.Average(10, 11, 12, 13);
            Assert.AreEqual<double>(11.5, r);
        }
    }
}
