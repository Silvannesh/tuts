﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArraysProject
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[] m = new int[3];
            /*
            m[0] = 10;
            m[2] = 17;*/


            //int[] m = new int[] { 10, 6, 17 };
            int[] m = { 10, 6, 17 };
            Console.WriteLine(m.Length);
            Console.WriteLine(m[1]);

            {
                int a = 10;
                int b = a;
                a++;

                Console.WriteLine(b);
            }
            {
                int[] a = { 10 };
                int[] b = (int[])a.Clone();
                a[0]++;

                Console.WriteLine(b[0]);
            }


            List<string> persons =
                new List<string>() 
                 { "Сергей", "Костя", "Саша" };
            /*
            persons.Add("Сергей");
            persons.Add("Костя");
            persons.Add("Саша");*/
            //for (int i = 0; i < persons.Count; i++)
            //    persons[i] = persons[i].ToUpper();
            //foreach (string person in persons)
            //    person = person.ToUpper();

            /*
            IEnumerator<string> en = persons.GetEnumerator();
            while (en.MoveNext())
            {
                //Console.WriteLine(en.Current);
                en.Current = en.Current.ToUpper();
            }*/


            foreach (string person in persons)
                Console.WriteLine(person);



            //persons.Sort();

            //for (int i = 0; i < persons.Count; i++ )
            //    Console.WriteLine(persons[i]);

            //Console.WriteLine(persons.Count);




            string[] names = new string[] { "Сергей", "Наталия", "Костя", "Саша" };
            Array.Sort(names);


            //Console.WriteLine(names[0].Length);
            //for (int i = 0; i < names.Length; i++)
            //    Console.WriteLine(names[i]);
            foreach(string s in names)
                Console.WriteLine(s);


            int[,] matrix = //new int[2,3];
            {
                {1,2,3},
                {4,5,6}
            };
            Console.WriteLine(matrix.Rank);
            Console.WriteLine(matrix.Length);
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                    Console.Write("{0, 3}", matrix[i, j]);

                Console.WriteLine();
            }

            int[][] m2 = 
            {
                new int[]{3,1,2},
                new int[]{4,5}
            };

            Array.Sort(m2[0]);

            for (int i = 0; i < m2.Length; i++)
            {
                for (int j = 0; j < m2[i].Length; j++)
                    Console.Write("{0, 3}", m2[i][j]);

                Console.WriteLine();
            }


        }
    }
}
