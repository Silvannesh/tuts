﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;


namespace TestCom
{
    class Program
    {

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int MessageBox(IntPtr hWnd, String text, String caption, uint type);

        static void Main(string[] args)
        {
            MessageBox(new IntPtr(0), "Hello World!", "Hello Dialog", 0);
            Application excel =
                new Application();

            excel.Visible = true;
            excel.Workbooks.Add();


            Console.ReadKey();

        }
    }
}
