﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Variables
{
    class Program
    {
        public static int z;

        readonly string name = "Sergey";
        const double PI = 3.1415;

        static bool B()
        {
            Console.WriteLine("B()");
            return false;
        }
        
        static void Main(string[] args)
        {
            {
                int a = 5; // 0101
                int b = a << 3; // 0101000
                int c = 7; // 0111
                int d = c >> 1; // 0011

                int u = 12;
                //0x1F
                // 0000010
                // (u & 2 != 0)


                Console.WriteLine(d);
                Console.WriteLine(b.ToString("x"));

            
            }

            {
                bool a = true;
                bool b = false;

                bool c = a && b;
                c = a || b;
                c = !a;

                c = a || !B();
            }
            {
                int a = 10;

                bool b = (a >= 0) && (a <= 100);

            }


            {
                char ch = '\u003F';
                Console.WriteLine(ch);
                Console.WriteLine(sizeof(char));

            }

            {
                int a = 10;
                //a = a * 2;
                //a *= 2;
                //a = a + 1;
                //a += 1;
                //a++;
                //++a;

                int b = a++ + ++a;

                Console.WriteLine("a = {0}\nb = {1}", a, b);



            }

            Program p = new Program();
            //p.name = "Sergey";
            //Program.PI

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(i);
            }

            //Console.WriteLine(i);
            {
                int w = 10;
                {
                    Console.WriteLine(w);
                }
            }
            {
                string w = "qqq";
                Console.WriteLine(w);
            }

            {

                int x, y;

                int q = 10;

                x = 10 + 1;
                y = x + 1;
                x = x + 2;

                System.String s; // null
                string s1;

                System.Int32 z = 100;
                int z1; // System.Int32
                //System.UInt32
                //uint

                short sh1; // System.Int16
                byte b1 = 0x1F; // System.Byte
                int k = b1; // implicit conv
                byte b2 = (byte)k;
                long l1 = 1000L; // System.Int64

                double d = 2D; // 123e-9
                float f = 2.5F;

                decimal m = 1.6M;

                int a = 5;
                double b = 2.5 + a / 2D;

                Console.WriteLine(b);

                string snum = "100";
                int n = int.Parse(snum);

                int n1;

                if (int.TryParse(snum, out n1))
                {

                }
            }

        }
    }
}
