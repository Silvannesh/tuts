﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesProject
{
    class TVSet
    {
        public void TVOn(object sender, EventArgs e)
        { 
            Console.WriteLine("Телевизор заработал");
        }
    }
}
