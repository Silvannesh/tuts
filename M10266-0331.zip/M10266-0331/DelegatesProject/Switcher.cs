﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesProject
{
    
    //public delegate void ElectricityOn(object sender, EventArgs args);
    //public delegate double MathFunction(double x);

    
    public class Switcher
    {

        public Func<double, double> f;
        //public MathFunction f;
        //public Action<object, EventArgs> Electricity;
        
        public event EventHandler Electricity;
        //public ElectricityOn Electricity;

        protected virtual void OnElectricity()
        {
            if (Electricity != null)
                Electricity(this, new EventArgs());
        }
        
        public void Switch()
        {
            OnElectricity();    
            //Electricity.BeginInvoke()
                //
        
        }
    }
}
