﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesProject
{
    public class Lamp
    {
        public void LightOn(object sender, EventArgs e)
        {
            Console.WriteLine("Лампа зажглась");
        }
    }
}
