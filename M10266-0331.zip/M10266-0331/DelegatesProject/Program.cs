﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesProject
{
    class Program
    {
        const int STEPS = 1000000;
        static double Integral(Func<double, double> f, double a, double b)
        {
            double h = (b - a) / STEPS;
            double summa = 0D;
            for (int i = 0; i < STEPS; i++)
            {
                double x = a + i * h + h / 2;
                double y = f(x);
                summa += y * h;
            }
            return summa;
        }
        
        static void Main(string[] args)
        {
            int k = 2;
            Func<double, double> l = x => Math.Sin(k*x*x);
            k = 3;
            
            double r1 = Integral(
                l,    
                0, Math.PI / 2);

            Console.WriteLine(r1);
            
            Switcher sw = new Switcher();
            Lamp lamp = new Lamp();
            TVSet tv = new TVSet();

            sw.Electricity += lamp.LightOn;
            sw.Electricity += new EventHandler(tv.TVOn);
                //new ElectricityOn(tv.TVOn);

            //sw.Electricity -= lamp.LightOn;
            sw.Electricity +=
                (delegate(object sender, EventArgs e)
                    {
                        Console.WriteLine("ПОЖАР");
                    }
                
                );
            sw.Electricity += (sender, e) => { Console.WriteLine("FIRE"); };

            //sw.Electricity(sw, new EventArgs());
            

            sw.Switch();

        }
    }
}
