﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Generics
{
    public class ReadonlyStorage<MyType>
        where MyType : IComparable<MyType>/*,  new()*/
    {
        private MyType data;
        public ReadonlyStorage(MyType data)
        {
            this.data = data;
        }
        public MyType Data
        { get { return data;  } }
    }
    
    
    class Program
    {
        static void Main(string[] args)
        {
            ReadonlyStorage<int> r1 = new ReadonlyStorage<int>(5);
            ReadonlyStorage<double> r2 = new ReadonlyStorage<double>(5.5);
            ReadonlyStorage<string> r3 = new ReadonlyStorage<string>("abc");
            Console.WriteLine(r1.Data);
            Console.WriteLine(r2.Data);
            Console.WriteLine(r3.Data);
        }
    }
}
