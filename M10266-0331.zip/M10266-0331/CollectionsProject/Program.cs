﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CollectionsProject
{
    class Person
    {
        public string Name
        { get; set; }
        public int Age
        { get; set; }

        public override string ToString()
        {
            return string.Format("{0} : {1}", Name, Age);
        }
    }
    
    class Program
    {
        static bool CheckParentness(string s)
        {
            Stack<char> p = new Stack<char>();
            for (int i = 0; i < s.Length; i++)
            { 
                char c = s[i];
                if (c == '(' || c == '[')
                    p.Push(c);
                if (c == ')')
                    if (p.Count == 0 || p.Pop() != '(') return false;
                if (c == ']')
                    if (p.Count == 0 || p.Pop() != '[') return false;
            }

            return p.Count == 0;
        }

        static IEnumerable<Person> FilterPerson(IEnumerable<Person> persons)
        {
            //var result = new List<Person>();

            foreach (Person p in persons)
                if (p.Age >= 18)
                    yield return p;
                    
                    
                    //result.Add(p);

            //return result;
        }
        
        static void Main(string[] args)
        {
            IEnumerable<Person> persons =
                new List<Person>()
                {
                    new Person(){Name = "Sergey", Age = 36},
                    new Person(){Name = "Kosty", Age = 7},
                    new Person(){Name = "Alex", Age = 4},
                    new Person(){Name = "Nataliya", Age = 32},
                };

            //var r = FilterPerson(persons);

            /*IEnumerable<Person> r =
                (from p in persons
                 where p.Age >= 18
                 orderby p.Name
                 select p);//;.First();*/

            int k = 0;
            var r = persons.
                Where(p => { k++; return p.Age >= 18; }).
                OrderBy(p => p.Name).
                Select(p => p); //.First();

            r = r.ToList();

            Console.WriteLine(r.GetType().FullName);
            foreach (var p in r)
                Console.WriteLine(p);

            foreach (var p in r)
                Console.WriteLine(p);

            Console.WriteLine(k);
            
            
            
            
            
            
            IList<string> names = new List<string>() { "Sergey", "Kosty" };
            foreach (string name in names)
                Console.WriteLine(name);

            IDictionary<string, int> family =
                new Dictionary<string, int>();

            family.Add("Sergey", 36);
            family.Add("Kosty", 7);

            string nm = "Kosty";
            if (family.ContainsKey(nm))
                Console.WriteLine("{0} : {1}", nm, family[nm]);

            string s = "(dhafg[(xfkgj)]k)zxj[sdaf]dfh([zxdfgjkl])";
            Console.WriteLine(CheckParentness(s));

        }
    }
}
