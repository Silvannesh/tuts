﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Strings
{
    class Program
    {
        static void Main(string[] args)
        {
            string fileName = @"..\..\text.txt";
            string hello = "\"При\\вет\"\n";//new String();
            string name = "Сергей\u003F";
            string result = hello + " " + name;
            result = result + "!";

            Console.WriteLine(result[result.Length-1]);
            Console.WriteLine(result.Replace("Сергей", "Костя"));

            result = result.Replace("Сергей", "Костя");
            
            Console.WriteLine(result.ToUpper());

            // VERY BAD
            /*
            result = "";
            for (int i = 1; i <= 100; i++)
                //result = result + i.ToString() + " ";
                result += i.ToString() + " ";*/

            StringBuilder sb = new StringBuilder();
            for (int i = 1; i <= 100; i++)
                sb.Append(i).Append(" ");

            result = sb.ToString();

            Console.WriteLine(result);


        }
    }
}
