﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enums
{
    enum Colors : byte { Red = 1, Green = 10, Blue = 100 }
    
    class Program
    {
        

        static void Main(string[] args)
        {
            Colors c = Colors.Green;
            int n = (int)c;

            c = (Colors)2;

            Console.WriteLine(n);
            Console.WriteLine(c);

        }
    }
}
