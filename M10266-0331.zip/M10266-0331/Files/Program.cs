﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Files
{
    class Program
    {

        const string FILENAME1 = @"..\..\test1.txt";
        const string DIR_NAME = @"..\..\";

        static void ShowDirectoryTree(DirectoryInfo dir, int margin = 0)
        {
            if (margin > 1000)
                return;
            
            string m = new String(' ', margin);
            DirectoryInfo[] dirs = dir.GetDirectories();
            foreach (DirectoryInfo d in dirs)
            {
                Console.WriteLine("{0}{1}", m, d.Name.ToUpper());
                ShowDirectoryTree(d, margin + 4);
            }

            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo f in files)
                Console.WriteLine("{0}{1}", m, f.Name.ToLower());
        }

        static void ShowDirectoryTree(string dir)
        {
            ShowDirectoryTree(new DirectoryInfo(dir));
        }


        static void Main(string[] args)
        {
            if (!File.Exists(FILENAME1))
                File.Create(FILENAME1);

            FileInfo fi = new FileInfo(FILENAME1);
            if (fi.Exists)
            {
                Console.WriteLine(
                    "{0} {1}",
                    fi.FullName, fi.CreationTime);
            }

            DirectoryInfo di = new DirectoryInfo(DIR_NAME);

            DirectoryInfo[] dirs =
                di.GetDirectories();

            foreach (DirectoryInfo dir in dirs)
                Console.WriteLine(dir.Name.ToUpper());

            FileInfo[] files =
                di.GetFiles();


            foreach (FileInfo file in files)
                Console.WriteLine(file.Name.ToLower());

            //ShowDirectoryTree(@"..\..\..\");

            File.AppendAllText(FILENAME1, "new line\n");
            string content = File.ReadAllText(FILENAME1);
            Console.WriteLine(content);

            //FileStream fs = new FileStream(FILENAME1, FileMode.Open);
            //StreamReader reader = new StreamReader(fs, true);

            StreamReader reader = new StreamReader(FILENAME1,true);
            //reader.BaseStream
            string s;
            while ((s = reader.ReadLine()) != null)
            {
                Console.WriteLine(s);
            }

            reader.Close();
            //fs.Close();

            FileStream fs = new FileStream(FILENAME1, FileMode.Open);
            //fs.ReadTimeout = 10000;
            StreamWriter writer = new StreamWriter(fs, Encoding.UTF8);
            try
            {
                fs.Seek(0, SeekOrigin.Begin);
                //fs.Seek(0, SeekOrigin.End);
                writer.WriteLine("test");
                //writer.Flush()
            }
            finally
            {
                writer.Close();
            }
            //fs.Close();

            Console.WriteLine(Path.GetTempFileName());
            string d_name = @"e:\m10266-0331\";
            string f_name = "test.txt";
            Console.WriteLine(Path.Combine(d_name, f_name));



        }
    }
}
