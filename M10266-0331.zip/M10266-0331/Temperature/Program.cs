﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Temperature
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите температуру (C): ");
            string cs = Console.ReadLine();
            double c = double.Parse(cs);

            double f = 9D / 5 * c + 32;

            Console.WriteLine("Температура (F): {0:f2}", f);
        }
    }
}
