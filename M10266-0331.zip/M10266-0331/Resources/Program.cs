﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Resources
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            DBConnection conn = new DBConnection();
            try
            {
                conn.Execute();
            }
            finally
            {
                conn.Dispose();
            }
            using (DBConnection conn = new DBConnection())
            {
                conn.Execute();
            }*/
            DBConnection conn = new DBConnection();
            conn.Execute();

            GC.Collect();
            


            Thread.Sleep(3000);
        }
    }
}
