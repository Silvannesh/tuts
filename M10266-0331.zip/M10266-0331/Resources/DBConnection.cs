﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Resources
{
    class DBConnection : IDisposable
    {
        public DBConnection()
        {
            Console.WriteLine("open connection");
        }

        public void Execute()
        {
            Console.WriteLine("execute query");
        }

        private bool isDisposed = false;
        public void Dispose()
        {
            if (!isDisposed)
            {
                Console.WriteLine("close connection");
                isDisposed = true;
                GC.SuppressFinalize(this);
            }
        }


        
        ~DBConnection()
        {
            Dispose();   
        }
    }
}
