﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToBinary
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 5;

            char[] bits = new char[8];
            for (int i = 7; i >= 0; i--)
            {
                bits[i] = (n % 2 == 0) ? '0' : '1';
                //n = n >> 1;
                n >>= 1;
            }

            //Array.Reverse(bits);
            string result = new String(bits);

            Console.WriteLine(result);

        }
    }
}
